# routes/goodies.py
from flask import Blueprint, jsonify
from utils.jwt_helper import token_required
from utils.response_formatter import success_response, error_response
from models.goodies_model import get_user_goodies, award_goodie

goodies_bp = Blueprint('goodies', __name__)

@goodies_bp.route('/', methods=['GET'])
@token_required
def list_goodies(current_user):
    goodies = get_user_goodies(current_user['user_id'])
    return success_response(goodies, 'Goodies listed')

@goodies_bp.route('/award', methods=['POST'])
@token_required
def award(current_user):
    if current_user['role'] != 'admin':  # Example admin-only
        return error_response('Unauthorized', 403)
    data = request.json  # e.g., {'user_id': '...', 'goodie_type': 'badge'}
    awarded = award_goodie(data['user_id'], data['goodie_type'])
    if not awarded:
        return error_response('Award failed', 400)
    return success_response({}, 'Goodie awarded')