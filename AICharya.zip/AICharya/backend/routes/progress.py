# routes/progress.py
from flask import Blueprint, request, jsonify
from utils.jwt_helper import token_required
from utils.response_formatter import success_response, error_response
from models.progress_model import get_user_progress, update_progress

progress_bp = Blueprint('progress', __name__)

@progress_bp.route('/<course_id>', methods=['GET'])
@token_required
def get_progress(current_user, course_id):
    progress = get_user_progress(current_user['user_id'], course_id)
    return success_response(progress or {}, 'Progress fetched')

@progress_bp.route('/<course_id>', methods=['POST'])
@token_required
def save_progress(current_user, course_id):
    data = request.json  # e.g., {'completed_lessons': [1,2,3], 'score': 85}
    updated = update_progress(current_user['user_id'], course_id, data)
    if not updated:
        return error_response('Update failed', 400)
    return success_response({}, 'Progress updated')