# routes/auth.py
from flask import Blueprint, request, jsonify
import bcrypt
from utils.jwt_helper import encode_jwt
from utils.response_formatter import success_response, error_response
from utils.validators import validate_registration, validate_login
from models.user_model import create_user, find_user_by_email

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/register', methods=['POST'])
def register():
    data = request.json
    if not validate_registration(data):
        return error_response('Invalid registration data', 400)
    
    email = data['email']
    if find_user_by_email(email):
        return error_response('Email already registered', 409)
    
    hashed_pw = bcrypt.hashpw(data['password'].encode('utf-8'), bcrypt.gensalt())
    user = {
        'username': data['username'],
        'email': email,
        'password': hashed_pw.decode('utf-8'),
        'role': 'student'  # Default role
    }
    user_id = create_user(user)
    return success_response({'user_id': str(user_id)}, 'User registered successfully', 201)

@auth_bp.route('/login', methods=['POST'])
def login():
    data = request.json
    if not validate_login(data):
        return error_response('Invalid login data', 400)
    
    user = find_user_by_email(data['email'])
    if not user or not bcrypt.checkpw(data['password'].encode('utf-8'), user['password'].encode('utf-8')):
        return error_response('Invalid credentials', 401)
    
    payload = {'user_id': str(user['_id']), 'role': user['role']}
    token = encode_jwt(payload)
    return success_response({'token': token}, 'Login successful')