# routes/ai_tutor.py
from flask import Blueprint, request, jsonify
from utils.jwt_helper import token_required
from utils.response_formatter import success_response, error_response
from utils.ai_helper import get_ai_response
from models.chat_model import save_chat_message

ai_tutor_bp = Blueprint('ai_tutor', __name__)

@ai_tutor_bp.route('/ask', methods=['POST'])
@token_required
def ask_ai(current_user):
    data = request.json
    if 'question' not in data:
        return error_response('Missing question', 400)
    
    response = get_ai_response(data['question'], current_user['user_id'])
    save_chat_message(current_user['user_id'], data['question'], response)
    return success_response({'response': response}, 'AI response')