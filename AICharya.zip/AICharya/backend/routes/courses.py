# routes/courses.py
from flask import Blueprint, jsonify
from utils.jwt_helper import token_required
from utils.response_formatter import success_response, error_response
from models.course_model import get_all_courses, get_course_by_id

courses_bp = Blueprint('courses', __name__)

@courses_bp.route('/', methods=['GET'])
@token_required
def list_courses(current_user):
    courses = get_all_courses()
    return success_response(courses, 'Courses listed')

@courses_bp.route('/<course_id>', methods=['GET'])
@token_required
def get_course(current_user, course_id):
    course = get_course_by_id(course_id)
    if not course:
        return error_response('Course not found', 404)
    return success_response(course, 'Course details')