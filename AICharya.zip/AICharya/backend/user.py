# routes/user.py
from flask import Blueprint, request, jsonify
from utils.jwt_helper import decode_jwt, token_required
from utils.response_formatter import success_response, error_response
from models.user_model import find_user_by_id, update_user

user_bp = Blueprint('user', __name__)

@user_bp.route('/profile', methods=['GET'])
@token_required
def get_profile(current_user):
    user = find_user_by_id(current_user['user_id'])
    if not user:
        return error_response('User not found', 404)
    user_data = {
        'username': user['username'],
        'email': user['email'],
        'role': user['role']
    }
    return success_response(user_data, 'Profile fetched')

@user_bp.route('/profile', methods=['PUT'])
@token_required
def update_profile(current_user):
    data = request.json
    updated = update_user(current_user['user_id'], data)
    if not updated:
        return error_response('Update failed', 400)
    return success_response({}, 'Profile updated')