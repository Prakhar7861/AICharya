# models/course_model.py
from bson.objectid import ObjectId
from app import mongo

# Assuming courses are pre-inserted; this is for fetching
def get_all_courses():
    courses = list(mongo.db.courses.find({}, {'_id': 0}))  # Exclude _id or convert as needed
    return courses

def get_course_by_id(course_id):
    return mongo.db.courses.find_one({'_id': ObjectId(course_id)}, {'_id': 0})