# models/progress_model.py
from bson.objectid import ObjectId
from app import mongo

def get_user_progress(user_id, course_id):
    return mongo.db.progress.find_one({'user_id': ObjectId(user_id), 'course_id': ObjectId(course_id)})

def update_progress(user_id, course_id, data):
    query = {'user_id': ObjectId(user_id), 'course_id': ObjectId(course_id)}
    update = {'$set': data}
    result = mongo.db.progress.update_one(query, update, upsert=True)
    return result.matched_count > 0 or result.upserted_id is not None