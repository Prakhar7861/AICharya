# models/user_model.py
from bson.objectid import ObjectId
from app import mongo

def create_user(user_data):
    return mongo.db.users.insert_one(user_data).inserted_id

def find_user_by_email(email):
    return mongo.db.users.find_one({'email': email})

def find_user_by_id(user_id):
    return mongo.db.users.find_one({'_id': ObjectId(user_id)})

def update_user(user_id, updates):
    if 'password' in updates:
        updates['password'] = bcrypt.hashpw(updates['password'].encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    result = mongo.db.users.update_one({'_id': ObjectId(user_id)}, {'$set': updates})
    return result.modified_count > 0