# models/goodies_model.py
from bson.objectid import ObjectId
from app import mongo

def get_user_goodies(user_id):
    goodies = list(mongo.db.goodies.find({'user_id': ObjectId(user_id)}))
    for g in goodies:
        g['_id'] = str(g['_id'])
        g['user_id'] = str(g['user_id'])
    return goodies

def award_goodie(user_id, goodie_type):
    goodie = {'user_id': ObjectId(user_id), 'type': goodie_type, 'awarded_at': datetime.utcnow()}
    return mongo.db.goodies.insert_one(goodie).inserted_id