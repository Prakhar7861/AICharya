# models/chat_model.py
from bson.objectid import ObjectId
from datetime import datetime
from app import mongo

def save_chat_message(user_id, question, response):
    message = {
        'user_id': ObjectId(user_id),
        'question': question,
        'response': response,
        'timestamp': datetime.utcnow()
    }
    mongo.db.chats.insert_one(message)