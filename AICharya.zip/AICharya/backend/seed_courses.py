# backend/seed_courses.py
# Run this once: python seed_courses.py
# It connects to MongoDB and inserts sample courses if the collection is empty.

from app import app, mongo
from bson.objectid import ObjectId

# Sample courses – feel free to add more!
courses = [
    {
        "_id": ObjectId(),
        "title": "HTML Basics",
        "slug": "html-basics",
        "description": "Learn the foundation of every webpage.",
        "level": "beginner",
        "duration": "4 hours",
        "lessons": [
            {
                "id": 1,
                "title": "What is HTML?",
                "content": "<h2>HTML stands for HyperText Markup Language</h2><p>It describes the structure of pages using markup.</p>",
                "quiz": [
                    {"question": "What does HTML stand for?", "options": ["HyperText Markup Language", "Home Tool Markup Language"], "answer": 0}
                ]
            },
            {
                "id": 2,
                "title": "Tags & Elements",
                "content": "<p>Use <code>&lt;p&gt;</code> for paragraphs, <code>&lt;img&gt;</code> for images, etc.</p>"
            },
            {
                "id": 3,
                "title": "Forms & Inputs",
                "content": "<p>Collect user data with <code>&lt;form&gt;</code> and <code>&lt;input&gt;</code>.</p>"
            }
        ],
        "tags": ["frontend", "basics"]
    },
    {
        "_id": ObjectId(),
        "title": "CSS Mastery",
        "slug": "css-mastery",
        "description": "Make your pages beautiful and responsive.",
        "level": "intermediate",
        "duration": "6 hours",
        "lessons": [
            {
                "id": 1,
                "title": "Selectors & Specificity",
                "content": "<p>Class, ID, element selectors and how they cascade.</p>"
            },
            {
                "id": 2,
                "title": "Flexbox Layout",
                "content": "<p>Modern one-dimensional layout with <code>display: flex</code>.</p>",
                "quiz": [
                    {"question": "What property aligns flex items?", "options": ["justify-content", "align-items"], "answer": 0}
                ]
            },
            {
                "id": 3,
                "title": "Grid Layout",
                "content": "<p>Two-dimensional layouts with CSS Grid.</p>"
            }
        ],
        "tags": ["frontend", "styling"]
    },
    {
        "_id": ObjectId(),
        "title": "JavaScript Essentials",
        "slug": "js-essentials",
        "description": "Add interactivity to your websites.",
        "level": "beginner",
        "duration": "8 hours",
        "lessons": [
            {
                "id": 1,
                "title": "Variables & Data Types",
                "content": "<p>let, const, var; strings, numbers, arrays, objects.</p>"
            },
            {
                "id": 2,
                "title": "DOM Manipulation",
                "content": "<p>Use <code>document.querySelector</code> to change the page.</p>"
            },
            {
                "id": 3,
                "title": "Events & Listeners",
                "content": "<p>Click, submit, keypress events.</p>"
            }
        ],
        "tags": ["frontend", "javascript"]
    },
    {
        "_id": ObjectId(),
        "title": "Python for Beginners",
        "slug": "python-beginners",
        "description": "Start coding with Python – simple and powerful.",
        "level": "beginner",
        "duration": "10 hours",
        "lessons": [
            {
                "id": 1,
                "title": "Hello World & Syntax",
                "content": "<p>Print, indentation, comments.</p>"
            },
            {
                "id": 2,
                "title": "Loops & Conditionals",
                "content": "<p>for, while, if-elif-else.</p>"
            }
        ],
        "tags": ["backend", "python"]
    },
    {
        "_id": ObjectId(),
        "title": "Flask Web Apps",
        "slug": "flask-apps",
        "description": "Build web backends with Flask.",
        "level": "intermediate",
        "duration": "12 hours",
        "lessons": [
            {
                "id": 1,
                "title": "Routes & Views",
                "content": "<p>@app.route, render_template.</p>"
            },
            {
                "id": 2,
                "title": "Forms & Databases",
                "content": "<p>WTForms, PyMongo integration.</p>"
            }
        ],
        "tags": ["backend", "flask"]
    },
    {
        "_id": ObjectId(),
        "title": "MongoDB Basics",
        "slug": "mongodb-basics",
        "description": "NoSQL database for modern apps.",
        "level": "beginner",
        "duration": "5 hours",
        "lessons": [
            {
                "id": 1,
                "title": "Documents & Collections",
                "content": "<p>JSON-like BSON documents.</p>"
            },
            {
                "id": 2,
                "title": "CRUD Operations",
                "content": "<p>insert_one, find, update_one, delete.</p>"
            }
        ],
        "tags": ["database", "mongodb"]
    }
]

# Seed only if empty (idempotent)
with app.app_context():
    if mongo.db.courses.count_documents({}) == 0:
        mongo.db.courses.insert_many(courses)
        print(f"✅ Seeded {len(courses)} courses into MongoDB!")
    else:
        print("⚠️  Courses already exist – skipping seed.")