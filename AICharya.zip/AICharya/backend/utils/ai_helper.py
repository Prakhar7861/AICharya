# utils/ai_helper.py
import config

def get_ai_response(question, user_id):
    # Placeholder: In real implementation, call LLM API with config.Config.AI_KEY
    # For now, return a stub response
    return f"AI Tutor response to '{question}': This is a placeholder. Implement LLM integration here."