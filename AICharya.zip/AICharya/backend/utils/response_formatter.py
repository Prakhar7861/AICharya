# utils/response_formatter.py
from flask import jsonify

def success_response(data, message, status=200):
    return jsonify({'success': True, 'data': data, 'message': message}), status

def error_response(message, status=400):
    return jsonify({'success': False, 'message': message}), status