# utils/jwt_helper.py
import jwt
from datetime import datetime, timedelta, timezone
from flask import request, jsonify
from functools import wraps
import config
from utils.response_formatter import error_response

def encode_jwt(payload):
    payload['exp'] = datetime.now(timezone.utc) + timedelta(hours=24)
    return jwt.encode(payload, config.Config.JWT_SECRET, algorithm='HS256')

def decode_jwt(token):
    try:
        return jwt.decode(token, config.Config.JWT_SECRET, algorithms=['HS256'])
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None

def token_required(f):
    @wraps(f)
    def decorator(*args, **kwargs):
        token = request.headers.get('Authorization')
        if not token:
            return error_response('Token is missing', 401)
        if token.startswith('Bearer '):
            token = token.split(' ')[1]
        data = decode_jwt(token)
        if not data:
            return error_response('Invalid token', 401)
        return f(data, *args, **kwargs)
    return decorator