# utils/validators.py
import re

def validate_registration(data):
    if not all(key in data for key in ['username', 'email', 'password']):
        return False
    if not re.match(r'[^@]+@[^@]+\.[^@]+', data['email']):
        return False
    if len(data['password']) < 8:
        return False
    return True

def validate_login(data):
    if not all(key in data for key in ['email', 'password']):
        return False
    return True