# config.py
import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    MONGO_URI = os.getenv('MONGO_URI')
    JWT_SECRET_KEY = os.getenv('JWT_SECRET')
    AI_KEY = os.getenv('AI_KEY')  # Placeholder for AI service key
    if not all([MONGO_URI, JWT_SECRET]):
        raise ValueError("Missing required environment variables")