# app.py
from flask import Flask
from flask_pymongo import PyMongo
from flask_cors import CORS
import config

app = Flask(__name__)
app.config['MONGO_URI'] = config.Config.MONGO_URI
mongo = PyMongo(app)
CORS(app)  # Adjust origins for production

# Register blueprints
from routes.auth import auth_bp
from routes.user import user_bp
from routes.courses import courses_bp
from routes.progress import progress_bp
from routes.goodies import goodies_bp
from routes.ai_tutor import ai_tutor_bp

app.register_blueprint(auth_bp, url_prefix='/api/auth')
app.register_blueprint(user_bp, url_prefix='/api/user')
app.register_blueprint(courses_bp, url_prefix='/api/courses')
app.register_blueprint(progress_bp, url_prefix='/api/progress')
app.register_blueprint(goodies_bp, url_prefix='/api/goodies')
app.register_blueprint(ai_tutor_bp, url_prefix='/api/ai_tutor')

@app.route('/api/health')
def health():
    return {"status": "healthy"}, 200

if __name__ == '__main__':
    app.run(debug=True)