import { useState } from "react";
import Layout from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Trophy, Flame, Zap, Star, Target, TrendingUp } from "lucide-react";

const Dashboard = () => {
  const [level] = useState(12);
  const [xp] = useState(3450);
  const [xpToNextLevel] = useState(4000);
  const [streak] = useState(7);

  const xpPercentage = (xp / xpToNextLevel) * 100;

  const stats = [
    { label: "Courses Completed", value: "8", icon: Trophy, color: "text-primary" },
    { label: "Daily Streak", value: `${streak} days`, icon: Flame, color: "text-accent" },
    { label: "Total XP", value: xp.toLocaleString(), icon: Zap, color: "text-primary" },
    { label: "Achievements", value: "24", icon: Star, color: "text-accent" },
  ];

  const recentActivity = [
    { course: "JavaScript Advanced", xp: 250, time: "2 hours ago" },
    { course: "CSS Grid Mastery", xp: 180, time: "Yesterday" },
    { course: "Python Basics", xp: 200, time: "2 days ago" },
  ];

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="glass-card rounded-3xl p-8 mb-8 shadow-elevated animate-slide-up" 
             style={{ background: "var(--gradient-card)" }}>
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex-1">
              <h1 className="text-4xl font-bold mb-2">
                Welcome back, <span className="gradient-text">Alex!</span>
              </h1>
              <p className="text-muted-foreground text-lg">
                You're doing amazing! Keep up the momentum 🚀
              </p>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-center">
                <div className="w-24 h-24 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-2 glow-effect animate-float">
                  <span className="text-3xl font-bold text-primary-foreground">{level}</span>
                </div>
                <p className="text-sm font-semibold text-muted-foreground">Level</p>
              </div>
            </div>
          </div>

          {/* XP Progress */}
          <div className="mt-6">
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-semibold flex items-center gap-2">
                <Zap className="w-4 h-4 text-primary" />
                XP Progress to Level {level + 1}
              </span>
              <span className="text-sm text-muted-foreground">
                {xp} / {xpToNextLevel} XP
              </span>
            </div>
            <Progress value={xpPercentage} className="h-3 glow-effect" />
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => {
            const Icon = stat.icon;
            return (
              <Card
                key={index}
                className="glass-card p-6 hover-lift cursor-pointer animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-center justify-between mb-4">
                  <Icon className={`w-8 h-8 ${stat.color}`} />
                  <Badge variant="secondary" className="text-xs">
                    <TrendingUp className="w-3 h-3 mr-1" />
                    +12%
                  </Badge>
                </div>
                <p className="text-3xl font-bold mb-1">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </Card>
            );
          })}
        </div>

        {/* Recent Activity */}
        <Card className="glass-card p-6 animate-slide-up" style={{ animationDelay: "400ms" }}>
          <div className="flex items-center gap-2 mb-6">
            <Target className="w-5 h-5 text-primary" />
            <h2 className="text-2xl font-bold">Recent Activity</h2>
          </div>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 rounded-xl bg-secondary/50 hover:bg-secondary transition-colors"
              >
                <div>
                  <p className="font-semibold">{activity.course}</p>
                  <p className="text-sm text-muted-foreground">{activity.time}</p>
                </div>
                <Badge className="glow-effect">
                  +{activity.xp} XP
                </Badge>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </Layout>
  );
};

export default Dashboard;
