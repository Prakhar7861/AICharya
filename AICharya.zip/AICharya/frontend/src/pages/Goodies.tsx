import Layout from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Gift, Coins, Trophy, Star, Award, Crown } from "lucide-react";
import { toast } from "sonner";

const Goodies = () => {
  const userCoins = 1250;

  const goodies = [
    {
      id: 1,
      name: "HTML Master Badge",
      description: "Show off your HTML expertise",
      cost: 500,
      icon: Award,
      rarity: "Common",
      owned: true,
    },
    {
      id: 2,
      name: "CSS Wizard Hat",
      description: "For the styling masters",
      cost: 800,
      icon: Crown,
      rarity: "Rare",
      owned: false,
    },
    {
      id: 3,
      name: "JavaScript Ninja Star",
      description: "Code with ninja-level skills",
      cost: 1000,
      icon: Star,
      rarity: "Rare",
      owned: false,
    },
    {
      id: 4,
      name: "Python Pro Trophy",
      description: "Python programming excellence",
      cost: 1200,
      icon: Trophy,
      rarity: "Epic",
      owned: false,
    },
    {
      id: 5,
      name: "Full-Stack Legend Crown",
      description: "The ultimate achievement",
      cost: 2500,
      icon: Crown,
      rarity: "Legendary",
      owned: false,
    },
    {
      id: 6,
      name: "Code Mentor Badge",
      description: "Help others on their journey",
      cost: 1500,
      icon: Award,
      rarity: "Epic",
      owned: false,
    },
  ];

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "Common":
        return "bg-muted text-muted-foreground";
      case "Rare":
        return "bg-primary/20 text-primary";
      case "Epic":
        return "bg-accent/20 text-accent";
      case "Legendary":
        return "bg-gradient-to-r from-primary to-accent text-primary-foreground";
      default:
        return "bg-muted";
    }
  };

  const handleRedeem = (goodie: typeof goodies[0]) => {
    if (goodie.owned) {
      toast.info("You already own this item!");
      return;
    }
    if (userCoins < goodie.cost) {
      toast.error("Not enough coins! Keep learning to earn more.");
      return;
    }
    toast.success(`Redeemed ${goodie.name}! Check your profile.`);
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 animate-slide-up">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div>
              <div className="flex items-center gap-3 mb-2">
                <Gift className="w-8 h-8 text-primary" />
                <h1 className="text-4xl font-bold gradient-text">Goodies Store</h1>
              </div>
              <p className="text-muted-foreground text-lg">
                Redeem your hard-earned coins for exclusive rewards
              </p>
            </div>
            <Card className="glass-card px-6 py-4 glow-effect">
              <div className="flex items-center gap-3">
                <Coins className="w-6 h-6 text-accent" />
                <div>
                  <p className="text-sm text-muted-foreground">Your Balance</p>
                  <p className="text-2xl font-bold">{userCoins} coins</p>
                </div>
              </div>
            </Card>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {goodies.map((goodie, index) => {
            const Icon = goodie.icon;
            const canAfford = userCoins >= goodie.cost;

            return (
              <Card
                key={goodie.id}
                className={`glass-card p-6 hover-lift animate-slide-up ${
                  !canAfford && !goodie.owned ? "opacity-60" : ""
                }`}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                {goodie.owned && (
                  <Badge className="absolute top-4 right-4 bg-success/20 text-success">
                    Owned
                  </Badge>
                )}

                <div className="mb-4">
                  <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-4 glow-effect">
                    <Icon className="w-8 h-8 text-primary-foreground" />
                  </div>
                  <Badge className={getRarityColor(goodie.rarity)} variant="secondary">
                    {goodie.rarity}
                  </Badge>
                </div>

                <h3 className="text-xl font-bold mb-2">{goodie.name}</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  {goodie.description}
                </p>

                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Coins className="w-5 h-5 text-accent" />
                    <span className="font-bold text-lg">{goodie.cost}</span>
                  </div>
                  <Button
                    onClick={() => handleRedeem(goodie)}
                    disabled={!canAfford || goodie.owned}
                    className={canAfford && !goodie.owned ? "glow-effect" : ""}
                    variant={goodie.owned ? "outline" : "default"}
                  >
                    {goodie.owned ? "Owned" : canAfford ? "Redeem" : "Locked"}
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      </div>
    </Layout>
  );
};

export default Goodies;
