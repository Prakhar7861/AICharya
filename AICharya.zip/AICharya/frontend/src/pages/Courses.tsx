import Layout from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { BookOpen, Clock, Zap, Lock, CheckCircle2 } from "lucide-react";

const Courses = () => {
  const courses = [
    {
      id: 1,
      title: "HTML Fundamentals",
      description: "Master the building blocks of the web",
      difficulty: "Beginner",
      duration: "4 hours",
      xp: 500,
      progress: 100,
      status: "completed",
      locked: false,
    },
    {
      id: 2,
      title: "CSS Styling & Layouts",
      description: "Create beautiful, responsive designs",
      difficulty: "Beginner",
      duration: "6 hours",
      xp: 650,
      progress: 75,
      status: "in-progress",
      locked: false,
    },
    {
      id: 3,
      title: "JavaScript Essentials",
      description: "Bring interactivity to your websites",
      difficulty: "Intermediate",
      duration: "8 hours",
      xp: 800,
      progress: 30,
      status: "in-progress",
      locked: false,
    },
    {
      id: 4,
      title: "Python Programming",
      description: "Learn the most popular programming language",
      difficulty: "Intermediate",
      duration: "10 hours",
      xp: 1000,
      progress: 0,
      status: "locked",
      locked: true,
    },
    {
      id: 5,
      title: "Flask Web Development",
      description: "Build powerful web applications with Flask",
      difficulty: "Advanced",
      duration: "12 hours",
      xp: 1200,
      progress: 0,
      status: "locked",
      locked: true,
    },
    {
      id: 6,
      title: "MongoDB Database Design",
      description: "Master NoSQL database management",
      difficulty: "Advanced",
      duration: "8 hours",
      xp: 1100,
      progress: 0,
      status: "locked",
      locked: true,
    },
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner":
        return "bg-success/20 text-success";
      case "Intermediate":
        return "bg-primary/20 text-primary";
      case "Advanced":
        return "bg-accent/20 text-accent";
      default:
        return "bg-muted";
    }
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8 animate-slide-up">
          <h1 className="text-4xl font-bold mb-2 gradient-text">Explore Courses</h1>
          <p className="text-muted-foreground text-lg">
            Level up your skills with our comprehensive learning paths
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {courses.map((course, index) => (
            <Card
              key={course.id}
              className={`glass-card p-6 hover-lift animate-slide-up ${
                course.locked ? "opacity-60" : ""
              }`}
              style={{ animationDelay: `${index * 100}ms` }}
            >
              {course.locked && (
                <div className="absolute top-4 right-4">
                  <Lock className="w-5 h-5 text-muted-foreground" />
                </div>
              )}

              {course.status === "completed" && (
                <div className="absolute top-4 right-4">
                  <CheckCircle2 className="w-5 h-5 text-success" />
                </div>
              )}

              <div className="mb-4">
                <div className="flex items-start justify-between mb-3">
                  <BookOpen className="w-8 h-8 text-primary" />
                  <Badge className={getDifficultyColor(course.difficulty)}>
                    {course.difficulty}
                  </Badge>
                </div>
                <h3 className="text-xl font-bold mb-2">{course.title}</h3>
                <p className="text-sm text-muted-foreground mb-4">
                  {course.description}
                </p>
              </div>

              <div className="space-y-3 mb-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Clock className="w-4 h-4" />
                  {course.duration}
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <Zap className="w-4 h-4 text-primary" />
                  <span className="font-semibold">{course.xp} XP</span>
                </div>
              </div>

              {!course.locked && course.progress > 0 && (
                <div className="mb-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-muted-foreground">Progress</span>
                    <span className="text-xs font-semibold">{course.progress}%</span>
                  </div>
                  <Progress value={course.progress} className="h-2" />
                </div>
              )}

              <Button
                className={`w-full ${
                  course.locked ? "opacity-50 cursor-not-allowed" : "glow-effect"
                }`}
                disabled={course.locked}
                variant={course.status === "completed" ? "outline" : "default"}
              >
                {course.locked
                  ? "Locked"
                  : course.status === "completed"
                  ? "Review"
                  : course.progress > 0
                  ? "Continue"
                  : "Start Course"}
              </Button>
            </Card>
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default Courses;
