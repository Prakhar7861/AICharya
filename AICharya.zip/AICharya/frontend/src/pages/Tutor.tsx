import { useState } from "react";
import Layout from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar } from "@/components/ui/avatar";
import { Brain, Send, Sparkles } from "lucide-react";

interface Message {
  id: number;
  text: string;
  isUser: boolean;
  timestamp: Date;
}

const Tutor = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      text: "Hi! I'm your AI tutor. I'm here to help you learn HTML, CSS, JavaScript, Python, Flask, and MongoDB. What would you like to learn today?",
      isUser: false,
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      text: input,
      isUser: true,
      timestamp: new Date(),
    };

    setMessages([...messages, userMessage]);

    // Mock AI response
    setTimeout(() => {
      const aiResponse: Message = {
        id: messages.length + 2,
        text: "That's a great question! Let me help you understand that concept. [This is a demo response - in production, this would connect to a real AI service]",
        isUser: false,
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, aiResponse]);
    }, 1000);

    setInput("");
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8 animate-slide-up">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center glow-effect">
              <Brain className="w-6 h-6 text-primary-foreground" />
            </div>
            <h1 className="text-4xl font-bold gradient-text">AI Tutor</h1>
          </div>
          <p className="text-muted-foreground text-lg">
            Ask me anything about coding! I'm here to help 24/7
          </p>
        </div>

        <Card className="glass-card shadow-elevated">
          {/* Chat Messages */}
          <div className="h-[500px] overflow-y-auto p-6 space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex gap-3 animate-slide-up ${
                  message.isUser ? "flex-row-reverse" : "flex-row"
                }`}
              >
                <Avatar className={`w-10 h-10 ${message.isUser ? "bg-primary" : "bg-accent"}`}>
                  {message.isUser ? (
                    <span className="text-primary-foreground font-semibold">U</span>
                  ) : (
                    <Brain className="w-5 h-5 text-accent-foreground p-1" />
                  )}
                </Avatar>
                <div
                  className={`flex-1 max-w-[80%] p-4 rounded-2xl ${
                    message.isUser
                      ? "bg-primary text-primary-foreground ml-auto"
                      : "bg-secondary"
                  }`}
                >
                  <p className="text-sm">{message.text}</p>
                  <p className="text-xs opacity-70 mt-2">
                    {message.timestamp.toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </p>
                </div>
              </div>
            ))}
          </div>

          {/* Input Area */}
          <div className="border-t border-border p-4">
            <div className="flex gap-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSend()}
                placeholder="Ask me anything about coding..."
                className="flex-1 glow-effect"
              />
              <Button onClick={handleSend} className="glow-effect">
                <Send className="w-4 h-4 mr-2" />
                Send
              </Button>
            </div>
            <div className="flex items-center gap-2 mt-3 text-xs text-muted-foreground">
              <Sparkles className="w-3 h-3" />
              <span>AI-powered responses • Available 24/7</span>
            </div>
          </div>
        </Card>
      </div>
    </Layout>
  );
};

export default Tutor;
