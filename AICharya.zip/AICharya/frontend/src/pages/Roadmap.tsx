import Layout from "@/components/Layout";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Circle, Lock } from "lucide-react";

const Roadmap = () => {
  const roadmapSteps = [
    {
      id: 1,
      title: "HTML Basics",
      description: "Learn the structure of web pages",
      status: "completed",
      level: 1,
    },
    {
      id: 2,
      title: "CSS Fundamentals",
      description: "Style your web pages beautifully",
      status: "completed",
      level: 3,
    },
    {
      id: 3,
      title: "JavaScript Essentials",
      description: "Add interactivity to your sites",
      status: "in-progress",
      level: 5,
    },
    {
      id: 4,
      title: "Advanced JavaScript",
      description: "Master modern JS concepts",
      status: "locked",
      level: 8,
    },
    {
      id: 5,
      title: "Python Programming",
      description: "Learn backend development",
      status: "locked",
      level: 12,
    },
    {
      id: 6,
      title: "Flask Framework",
      description: "Build web applications",
      status: "locked",
      level: 15,
    },
    {
      id: 7,
      title: "MongoDB Database",
      description: "Store and manage data",
      status: "locked",
      level: 18,
    },
    {
      id: 8,
      title: "Full-Stack Project",
      description: "Build your portfolio project",
      status: "locked",
      level: 20,
    },
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed":
        return <CheckCircle2 className="w-8 h-8 text-success" />;
      case "in-progress":
        return <Circle className="w-8 h-8 text-primary animate-pulse" />;
      case "locked":
        return <Lock className="w-8 h-8 text-muted-foreground" />;
      default:
        return <Circle className="w-8 h-8 text-muted-foreground" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-success/20 text-success";
      case "in-progress":
        return "bg-primary/20 text-primary";
      case "locked":
        return "bg-muted text-muted-foreground";
      default:
        return "bg-muted";
    }
  };

  return (
    <Layout>
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8 animate-slide-up">
          <h1 className="text-4xl font-bold mb-2 gradient-text">Your Learning Roadmap</h1>
          <p className="text-muted-foreground text-lg">
            Follow this path to become a full-stack developer
          </p>
        </div>

        <div className="relative">
          {/* Timeline Line */}
          <div className="absolute left-8 top-0 bottom-0 w-0.5 bg-gradient-to-b from-primary via-accent to-muted" />

          <div className="space-y-8">
            {roadmapSteps.map((step, index) => (
              <div
                key={step.id}
                className={`relative animate-slide-up ${
                  step.status === "locked" ? "opacity-60" : ""
                }`}
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="flex items-start gap-6">
                  {/* Icon */}
                  <div className="relative z-10 flex-shrink-0">
                    <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                      step.status === "completed" ? "bg-success/20" :
                      step.status === "in-progress" ? "bg-primary/20 glow-effect" :
                      "bg-muted"
                    }`}>
                      {getStatusIcon(step.status)}
                    </div>
                  </div>

                  {/* Content */}
                  <Card
                    className={`flex-1 glass-card p-6 hover-lift ${
                      step.status === "in-progress" ? "border-primary glow-effect" : ""
                    }`}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-xl font-bold mb-1">{step.title}</h3>
                        <p className="text-sm text-muted-foreground">
                          {step.description}
                        </p>
                      </div>
                      <Badge className={getStatusColor(step.status)}>
                        {step.status === "in-progress" ? "Current" : 
                         step.status === "completed" ? "Done" : "Locked"}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <span>Unlocks at Level {step.level}</span>
                    </div>
                  </Card>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default Roadmap;
