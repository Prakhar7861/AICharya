import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import Layout from "@/components/Layout";
import { Sparkles, Zap, Trophy, Brain, ArrowRight, Code2, Rocket, Star } from "lucide-react";

const Index = () => {
  const features = [
    {
      icon: Code2,
      title: "Learn by Doing",
      description: "Interactive courses with hands-on coding challenges",
    },
    {
      icon: Zap,
      title: "Earn XP & Level Up",
      description: "Track your progress with gamified learning",
    },
    {
      icon: Brain,
      title: "AI Tutor 24/7",
      description: "Get instant help whenever you're stuck",
    },
    {
      icon: Trophy,
      title: "Unlock Rewards",
      description: "Earn badges, coins, and exclusive goodies",
    },
  ];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center max-w-4xl mx-auto animate-slide-up">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 mb-6">
            <Sparkles className="w-4 h-4 text-primary" />
            <span className="text-sm font-semibold text-primary">Welcome to AICharya</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Learn to Code with{" "}
            <span className="gradient-text">Fun & Gamification</span>
          </h1>
          
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Master HTML, CSS, JavaScript, Python, Flask, and MongoDB through interactive lessons, 
            AI-powered tutoring, and exciting rewards.
          </p>

          <div className="flex flex-wrap items-center justify-center gap-4">
            <Link to="/signup">
              <Button size="lg" className="glow-effect hover-lift text-lg px-8">
                Start Learning Free
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Link to="/login">
              <Button size="lg" variant="outline" className="text-lg px-8">
                Sign In
              </Button>
            </Link>
          </div>
        </div>

        {/* Animated Hero Card */}
        <div className="mt-16 max-w-5xl mx-auto animate-slide-up" style={{ animationDelay: "200ms" }}>
          <Card className="glass-card p-8 shadow-elevated glow-effect">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
              <div>
                <div className="text-4xl font-bold gradient-text mb-2">5K+</div>
                <div className="text-sm text-muted-foreground">Active Students</div>
              </div>
              <div>
                <div className="text-4xl font-bold gradient-text mb-2">6</div>
                <div className="text-sm text-muted-foreground">Courses</div>
              </div>
              <div>
                <div className="text-4xl font-bold gradient-text mb-2">50+</div>
                <div className="text-sm text-muted-foreground">Hours Content</div>
              </div>
              <div>
                <div className="text-4xl font-bold gradient-text mb-2">24/7</div>
                <div className="text-sm text-muted-foreground">AI Support</div>
              </div>
            </div>
          </Card>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-12 animate-slide-up">
          <h2 className="text-4xl font-bold mb-4">Why Choose AICharya?</h2>
          <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
            Learning to code has never been this fun, engaging, and rewarding
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <Card
                key={index}
                className="glass-card p-6 hover-lift animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-primary to-accent flex items-center justify-center mb-4 glow-effect">
                  <Icon className="w-6 h-6 text-primary-foreground" />
                </div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-sm text-muted-foreground">{feature.description}</p>
              </Card>
            );
          })}
        </div>
      </section>

      {/* CTA Section */}
      <section className="container mx-auto px-4 py-20">
        <Card
          className="glass-card p-12 shadow-elevated glow-effect animate-slide-up"
          style={{ background: "var(--gradient-card)" }}
        >
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex w-16 h-16 rounded-2xl bg-gradient-to-br from-primary to-accent items-center justify-center mb-6 glow-effect animate-float">
              <Rocket className="w-8 h-8 text-primary-foreground" />
            </div>
            <h2 className="text-4xl font-bold mb-4">Ready to Start Your Coding Journey?</h2>
            <p className="text-muted-foreground text-lg mb-8">
              Join thousands of students who are already leveling up their skills
            </p>
            <Link to="/signup">
              <Button size="lg" className="glow-effect hover-lift text-lg px-8">
                Get Started Now
                <Star className="w-5 h-5 ml-2" />
              </Button>
            </Link>
          </div>
        </Card>
      </section>
    </Layout>
  );
};

export default Index;
